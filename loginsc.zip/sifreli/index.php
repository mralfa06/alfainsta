<?php
header("Location: base.php");
?>

