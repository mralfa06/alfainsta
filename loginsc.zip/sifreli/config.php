<?php
	$site_url = "http://localhost/resimyukleme/";

?>